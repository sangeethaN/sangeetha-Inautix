package Classes;
import Interface.Performer;


public class Instrumentalist implements Performer{

	public void perform() {
		// TODO Auto-generated method stub
		System.out.println("Instrumentalist is performing");
	}

}
