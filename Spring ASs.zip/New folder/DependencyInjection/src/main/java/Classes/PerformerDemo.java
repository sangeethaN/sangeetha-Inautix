package Classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import Interface.Performer;

public class PerformerDemo {
	public static void main(String args[]){
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {"spring-servlet.xml"});
	
		Performer singer = (Performer)appContext.getBean("Singer");
		singer.perform();
	}
}
