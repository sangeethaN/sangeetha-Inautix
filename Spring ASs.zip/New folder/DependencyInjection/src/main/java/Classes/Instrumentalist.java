package Classes;

import Interface.Instrument;
import Interface.Performer;

public class Instrumentalist implements Performer{
	
	private Instrument instrument;
	
	public void perform() {
		// TODO Auto-generated method stub
		System.out.println("Instrumentalist is performing");
		instrument.play();
	}

	public Instrument getInstrument() {
		return instrument;
	}

	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}

}
