package Classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import Interface.Performer;

public class PerformanceDemo {
	public static void main(String args[]){
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {"spring-servlet.xml"});
		
		Performer instrumentalist = (Performer)appContext.getBean("Instrumentalist");
		instrumentalist.perform();
	}
}