package Classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutoWireBeanDemo1 {
	public static void main(String[] args){
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] { "spring1.xml"});
		Musician musician = (Musician) appContext.getBean("Musician");
		musician.perform();
		
	}
}
