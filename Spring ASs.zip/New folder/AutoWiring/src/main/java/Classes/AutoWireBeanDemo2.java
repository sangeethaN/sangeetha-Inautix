package Classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import Interface.Performer;

public class AutoWireBeanDemo2 {
	public static void main(String args[]){
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] { "spring2.xml"});
		
		Performer guitarist = (Performer) appContext.getBean("Guitarist");
		guitarist.perform();
	}
}
