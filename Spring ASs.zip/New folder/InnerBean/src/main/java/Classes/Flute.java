package Classes;

import Interface.Instrument;

public class Flute implements Instrument{

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Flute: ku ku ku");
	}

}
