package Classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import Interface.Performer;

public class CollectionBeanDemo {
	public static void main(String args[]){
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {"spring2.xml"});
		Performer oneManBand = (Performer)appContext.getBean("oneManBand");
		oneManBand.perform();
	}
}
