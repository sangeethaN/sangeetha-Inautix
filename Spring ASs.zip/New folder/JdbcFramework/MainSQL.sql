set schema sample;

create table T_XBBNHBS_BookDetails(id int primary key, bookName varchar(50), author varchar(50));
insert into T_XBBNHBS_BookDetails values(1, 'The Screaming Staircase', 'Jonathan Stroud');

select * from T_XBBNHBS_BookDetails;