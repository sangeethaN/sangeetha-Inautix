package Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookDetailsController {
	
	@Autowired
	BookDetailsDao dao;
	
	@RequestMapping(value="/books", method=RequestMethod.POST, consumes= MediaType.APPLICATION_JSON_VALUE)
	public String createBookDetails(@RequestBody BookDetailsBean book){
		try{
			int numRows = dao.createBookDetails(book);
			if(numRows != 0){
				return "Successfully Inserted";
			}
			else{
				throw new Exception();
			}
		}
		catch(Exception e){
			return "Not Successfully Inserted";
		}
	}
	
	@RequestMapping(value="/books/{id}", method=RequestMethod.GET)
	public BookDetailsBean getBookDetails(@PathVariable int id){
		try{
			BookDetailsBean book = dao.getBookDetails(id);
			return book;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping(value="/bookUpdate", method=RequestMethod.PUT, consumes= MediaType.APPLICATION_JSON_VALUE)
	public String updateBookDetails(@RequestBody BookDetailsBean book){
		try{
			int numRows = dao.updateBookDetails(book);
			if(numRows != 0){
				return "Successfully Updated";
			}
			else{
				throw new Exception();
			}
		}
		catch(Exception e){
			e.printStackTrace();
			return "Not Successfully Updated";
		}
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	public String deleteBookDetails(@PathVariable int id){
		try{
			int numRows = dao.deleteBookDetails(id);
			if(numRows != 0){
				return "Successfully Deleted";
			}
			else{
				throw new Exception();
			}
		}
		catch(Exception e){
			return "Not Successfully Deleted";
		}
	}
}
