package Classes;

public class JavaBeanDemo {
	public static void main(String args[]){
		Restaurant restaurant = new Restaurant();
		restaurant.getGroceries();
		restaurant.getVegetables();
	}
}
