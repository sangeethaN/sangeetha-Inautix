package com.stock.dao;

public class wholesalevendor {
	private String vendorid;
	private String identity;
	private String name;
	private int qunatityInStock;
	private double maximumRetailPrice;
	private double discount;
	private String vendor;
	private String manufacturingDate;
	private String expiryDate;
	public wholesalevendor(String vendorid, String identity, String name,
			int qunatityInStock, double maximumRetailPrice, double discount,
			String vendor, String manufacturingDate, String expiryDate) {
		super();
		this.vendorid = vendorid;
		this.identity = identity;
		this.name = name;
		this.qunatityInStock = qunatityInStock;
		this.maximumRetailPrice = maximumRetailPrice;
		this.discount = discount;
		this.vendor = vendor;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
	}
	public String getVendorid() {
		return vendorid;
	}
	public void setVendorid(String vendorid) {
		this.vendorid = vendorid;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQunatityInStock() {
		return qunatityInStock;
	}
	public void setQunatityInStock(int qunatityInStock) {
		this.qunatityInStock = qunatityInStock;
	}
	public double getMaximumRetailPrice() {
		return maximumRetailPrice;
	}
	public void setMaximumRetailPrice(double maximumRetailPrice) {
		this.maximumRetailPrice = maximumRetailPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getManufacturingDate() {
		return manufacturingDate;
	}
	public void setManufacturingDate(String manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	
}
