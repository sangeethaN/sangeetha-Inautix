package com.stock.dao.cmp;

import java.util.Comparator;

import com.stock.dao.Item;

public class IdentityAscending implements Comparator<Item> {

	@Override
	public int compare(Item item1, Item item2) {
		
		return item1.getIdentity().compareTo(item2.getIdentity());
	}
	
}
