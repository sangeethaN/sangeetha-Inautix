package com.stock.dao;
import com.stock.utils.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.stock.utils.Database;

/**
 * Servlet implementation class LoginValidation
 */
@WebServlet("/LoginValidation")
public class LoginValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginValidation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
		PrintWriter out = response.getWriter();
		String userid = request.getParameter("auth_id");
		    String key = request.getParameter("auth_key");
		    String des = request.getParameter("user_type");
		    HttpSession session = request.getSession();

		    session.setAttribute("user",userid);
		   
		    Database db = new Database();
		    try {
		    if(des.equals("Admin"))
		    {
		    PreparedStatement ps = db.getPS("SELECT * FROM xbbnhhm_stocks_admin WHERE userid=? AND PASSWORD=? AND usertype=?");
		    
		    
				ps.setString(1, userid);
			
		    ps.setString(2, key);
		    ps.setString(3,des);
		  
		    ResultSet rs = ps.executeQuery();
		    if(rs.next()) {
		    out.println("Login Success");
		   Cookies.set(response,"auth_user",userid);
		  // out.println(userid+key+des);
		    out.println("<meta http-equiv='refresh' content='3,url=index.jsp'/>");
		    } else {
		    out.println("Failed");
		    out.println("<meta http-equiv='refresh' content='3,url=frontpage.jsp'/>");
		    }
		    db.close();
		    }
		    else if(des.equals("Retail_Vendor"))
		    {
		    	PreparedStatement ps = db.getPS("SELECT * FROM XBBNHHM_STOCKS_USER WHERE USERID=? AND PASSWORD=? AND USERTYPE=?");
		        
		        ps.setString(1, userid);
		        ps.setString(2, key);
		        ps.setString(3,des);
		       // HttpSession sessions = request.getSession(true);
		       
		        ResultSet rs = ps.executeQuery();
		        if(rs.next()) {
		        out.println("Login Success");
		        Cookies.set(response,"auth_id",userid);
		        out.println("<meta http-equiv='refresh' content='5,url=indexuser.jsp'/>");
		        } else {
		        out.println("Failed");
		        out.println("<meta http-equiv='refresh' content='5,url=frontpage.jsp'/>");
		        }
		        db.close();
		    
		    }
		    else if(des.equals("Whole_Sale_vendor"))
		    {
		    	PreparedStatement ps = db.getPS("SELECT * FROM xbbnhhm_stocks_wholesalevendor WHERE USERID=? AND PASSWORD=? AND USERTYPE=?");
		        
		        ps.setString(1, userid);
		        ps.setString(2, key);
		        ps.setString(3,des);
		       
		       
		        ResultSet rs = ps.executeQuery();
		        if(rs.next()) {
		        out.println("Login Success");
		        Cookies.set(response,"auth_id",userid);
		        out.println("<meta http-equiv='refresh' content='5,url=wholesalevendor.jsp'/>");
		        } else {
		        out.println("Failed");
		        out.println("<meta http-equiv='refresh' content='5,url=frontpage.jsp'/>");
		        }
		        db.close();
		    
		    }
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		// TODO Auto-generated method stub
	}

}
